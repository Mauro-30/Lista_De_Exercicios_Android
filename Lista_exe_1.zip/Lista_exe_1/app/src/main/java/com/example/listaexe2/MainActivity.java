package com.example.listaexe2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    EditText adicionar;
    Button conversor;
    TextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        adicionar =findViewById(R.id.adicionar);
        conversor =findViewById(R.id.bt_conversor);
        resultado =findViewById(R.id.txt_resultado);



       conversor.setOnClickListener(new OnClickListener() {
           @Override
           public void onClick(View v) {
               double tempoC= Double.parseDouble(adicionar.getText().toString());
               Double tempoF= tempoC * 1.8 + 32;

               resultado.setText(String.valueOf(tempoF));
           }
       });
    }
}