package com.example.lista_exe_10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    EditText Valor;
    Button converter_dólar;
    Button converter_Kwanza;
    Button converter_Real;
    TextView resultado;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Valor=findViewById(R.id.Valor);
        converter_dólar=findViewById(R.id.converter_dólar);
        converter_Kwanza=findViewById(R.id.converter_Kwanza);
        converter_Real=findViewById(R.id.converter_Real);



        converter_dólar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                double valorEuros=Double.parseDouble(Valor.getText().toString());
                DecimalFormat arredondar=new DecimalFormat("#.##");
                double resultadoDolares= valorEuros * 0.80;
                Toast.makeText(MainActivity.this, "Valor em dolares é:"+resultadoDolares, Toast.LENGTH_SHORT).show();
            }
        });
        converter_Real.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double valorEuros=Double.parseDouble(Valor.getText().toString());
                DecimalFormat arredondar=new DecimalFormat("#.##");
                double resultadoReal= valorEuros * 6.34;
                Toast.makeText(MainActivity.this, "O valor em Reais é:"+resultadoReal, Toast.LENGTH_SHORT).show();
            }
        });

        converter_Kwanza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double valorEuros=Double.parseDouble(Valor.getText().toString());
                DecimalFormat arredondar=new DecimalFormat("#.##");
                double resultadoKwanza= valorEuros * 796.11;
                Toast.makeText(MainActivity.this, "O valor em Kwanzas  é:"+resultadoKwanza, Toast.LENGTH_SHORT).show();
            }
        });
    }
}