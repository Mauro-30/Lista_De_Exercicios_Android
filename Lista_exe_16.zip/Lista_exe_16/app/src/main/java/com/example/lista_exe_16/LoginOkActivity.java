package com.example.lista_exe_16;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class LoginOkActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_ok);
    }
}