package com.example.lista_exe_18;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText numero;
    Button calcular;
    TextView resultado;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        numero = findViewById(R.id.numero);
        calcular = findViewById(R.id.btn_primo);
        resultado = findViewById(R.id.resultado);

        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int num = Integer.parseInt(numero.getText().toString());
                int cont = 0;
                String primo="";

                for (int i = 1; i < num; i++) {
                    if (num % i == 0){
                        cont++;
                    }
                        if (cont==2){
                            primo="Sim é Primo";
                    }else{
                        primo="Não é primo";
                    }
                }
                resultado.setText("O número é :"+ primo);
            }
        });
    }
}