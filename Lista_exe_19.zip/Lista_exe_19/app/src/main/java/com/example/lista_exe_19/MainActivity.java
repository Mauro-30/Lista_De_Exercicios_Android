package com.example.lista_exe_19;

import androidx.annotation.IntegerRes;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText horas;
    Button btn_calculos;
    TextView txt_semanas,txt_dias,txt_horas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        horas = findViewById(R.id.EDT_horas);
        btn_calculos = findViewById(R.id.bt_calcular);
        txt_semanas = findViewById(R.id.txt_semanas);
        txt_dias = findViewById(R.id.txt_dias);
        txt_horas = findViewById(R.id.txt_horas);

        btn_calculos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int htotal = Integer.parseInt(horas.getText().toString());
                int nsemanas =htotal/24*7;
                txt_semanas.setText(nsemanas + "  semanas");

                int ndias =(htotal%24/7)/24;
                int nHoras= (htotal%24/7)%24;

                txt_dias.setText(ndias +"  dias");
                txt_horas.setText(nHoras+" horas");

            }
        });
    }
}