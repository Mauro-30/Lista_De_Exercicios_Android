package com.example.lista_exe_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText primeiro_nome;
    EditText sobrenome_nome;
    Button concatenar;
    TextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        primeiro_nome=findViewById(R.id.primeiro_nome);
        sobrenome_nome=findViewById(R.id.sobrenome_nome);
        concatenar=findViewById(R.id.btn_Concatenar);
        resultado=findViewById(R.id.txt_resultado);

        concatenar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 String nome=primeiro_nome.getText().toString();
                 String sobrenome =sobrenome_nome.getText().toString();

                 if(nome.isEmpty() || sobrenome.isEmpty() ){
                      resultado.setText("Nome não inserido");
                 }else {
                     resultado.setText("Olá  "+ nome +" "+ sobrenome);
                 }

            }
        });

    }
}