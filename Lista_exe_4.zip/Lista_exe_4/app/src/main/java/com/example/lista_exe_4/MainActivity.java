package com.example.lista_exe_4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText nascimento;
    EditText ano_actual;
    Button btn_idade;
    Button btn_idade_em;
    TextView resultado_idade;
    TextView resultado_idade_em;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nascimento=findViewById(R.id.EDT_nascimento);
        ano_actual=findViewById(R.id.EDT_ano);
        btn_idade=findViewById(R.id.btn_idade);
        resultado_idade=findViewById(R.id.txt_resultado_idade);
        resultado_idade_em=findViewById(R.id.txt_resultado_em);

        btn_idade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int nascido= Integer.parseInt(nascimento.getText().toString());
                int ano=Integer.parseInt(ano_actual.getText().toString());
                int anos_de_idade=ano-nascido;
                int idade_em = 2050-nascido;
                resultado_idade.setText("A idade é: "+ anos_de_idade);
                resultado_idade_em.setText("Em 2050 terá:"+ idade_em);


            }
        });
    }
}