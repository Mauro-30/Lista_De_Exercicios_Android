package com.example.lista_exe_5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText salario_base;
    Button calcular_salario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        salario_base=findViewById(R.id.EDT_salario);
        calcular_salario=findViewById(R.id.btn_salario);

        calcular_salario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double salario=Double.parseDouble(salario_base.getText().toString());
                double salario_gratificado=((salario*5)/100);
                double imposto=(salario*7)/100;
                double salario_final=salario-imposto+salario_gratificado;

                Toast.makeText(MainActivity.this,"O salário do funcionário é:"+salario_final,Toast.LENGTH_LONG).show();
            }
        });
    }
}