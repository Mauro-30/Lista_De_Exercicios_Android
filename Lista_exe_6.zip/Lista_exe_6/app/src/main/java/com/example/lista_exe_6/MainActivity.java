package com.example.lista_exe_6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText peso_base;
    Button calcular_peso;
    TextView engordei;
    TextView emagreci;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        peso_base=findViewById(R.id.EDT_peso);
        calcular_peso=findViewById(R.id.btn_peso);
        engordei=findViewById(R.id.txt_engordar);
        emagreci=findViewById(R.id.txt_emagrecer);

        calcular_peso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double peso=Double.parseDouble(peso_base.getText().toString());
                double engordar=peso+((peso*15)/100);
                double emagrecimento=peso-((peso*20)/100);

                engordei.setText(String.valueOf("O novo peso engordando 15% é:"+engordar));
                emagreci.setText(String.valueOf("O novo peso emagrecendo 20% é:"+emagrecimento));
            }
        });
    }
}