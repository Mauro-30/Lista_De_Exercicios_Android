package com.example.lista_exe_7;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText preco;
    EditText lucro;
    EditText percent_imposto;
    Button resultado;
    TextView valor_do_lucro;
    TextView valor_do_imposto;
    TextView preco_final;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        preco=findViewById(R.id.EDT_preco);
        lucro=findViewById(R.id.EDT_percent_lucro);
        percent_imposto=findViewById(R.id.EDT_percentual_imposto);
        resultado=findViewById(R.id.btn_resultado);
        valor_do_lucro=findViewById(R.id.txt_valor_do_lucro);
        valor_do_imposto=findViewById(R.id.txt_valor_do_imposto);
        preco_final=findViewById(R.id.txt_preco_final);

        resultado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double preco_fabrica=Double.parseDouble(preco.getText().toString());
                double percent_lucro=Double.parseDouble(lucro.getText().toString());
                double percentual_imposto=Double.parseDouble(percent_imposto.getText().toString());
                double valor_distri=(preco_fabrica*percent_lucro)/100;
                double valor_imposto=(preco_fabrica*percentual_imposto)/100;
                double valor_final=preco_fabrica+valor_distri+valor_imposto;

                valor_do_lucro.setText(String.valueOf("O valor do lucro do distribuidor é: "+ valor_distri ));
                valor_do_imposto.setText(String.valueOf("O valor do imposto é: "+ valor_imposto ));
                preco_final.setText(String.valueOf("O preço final do veículo é: "+ valor_final));
            }
        });
    }
}