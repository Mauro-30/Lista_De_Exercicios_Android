package com.example.lista_exe_8;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText salario;
    EditText quantidade_de_quilowatt;
    Button resultado;
    TextView valor_por_quilowatt;
    TextView valor_por_essa_residencia;
    TextView valor_com_desconto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        salario=findViewById(R.id.EDT_salario);
        quantidade_de_quilowatt=findViewById(R.id.EDT_quanti_quillo);
        resultado=findViewById(R.id.btn_resultado);
        valor_por_quilowatt=findViewById(R.id.txt_valor_por_quiloWatt);
        valor_por_essa_residencia=findViewById(R.id.txt_valor_pago_por_residência);
        valor_com_desconto=findViewById(R.id.txt_valor_pago_desconto);

        resultado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double salario_minimo=Double.parseDouble(salario.getText().toString());
                double quantidade_de_quilowatts=Double.parseDouble(quantidade_de_quilowatt.getText().toString());
                double valor_por_quill=salario_minimo/5;
                double valor_a_ser_pago=quantidade_de_quilowatts*valor_por_quill;
                double valor_a_ser_pago_com_desconto=valor_a_ser_pago-((valor_a_ser_pago*15)/100);

                valor_por_quilowatt.setText(String.valueOf("O valor de cada quilowatt é:"+ valor_por_quill));
                valor_por_essa_residencia.setText(String.valueOf("O valor pago por essa resistência é:"+ valor_a_ser_pago));
                valor_com_desconto.setText(String.valueOf("O valor a ser pago com desconto de 15% é:"+ valor_a_ser_pago_com_desconto));

            }
        });
    }
}